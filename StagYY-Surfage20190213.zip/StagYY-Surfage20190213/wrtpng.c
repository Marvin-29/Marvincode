#include <stdlib.h>
#include <stdio.h>
#include <png.h>

int png_present_()
{  
  return 1;
}

int write_png_( char *fileName, unsigned long long  *img, int *columns, int *rows)
{
  unsigned long pixel;
  int c,r,pix;
  char * gamma_str;
  double screen_gamma;
  png_structp png_ptr;
  png_infop info_ptr;
  png_bytep* row_pointers;
  FILE *fp;

  int i;

  for(i=0;fileName[i] != '\0' && fileName[i]!=' ';i++);
  fileName[i]='\0';
  
  fp = fopen(fileName, "wb");
  if (!fp)
    {
      printf(" write_png: error opening image file - check directory exists \n ");
      return(-1);
    }
  else
    {
      png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING,NULL, NULL, NULL);
      if (!png_ptr)
	{
	  printf("void fImageT<T>::writePNG(const string&) const");
	}
      info_ptr = png_create_info_struct(png_ptr);
      if (!info_ptr)
	{
	  printf("void fImageT<T>::writePNG(const string&) const");
	}
      png_init_io(png_ptr, fp);
      
      /* Fillin the info structure.*/
      png_set_IHDR(png_ptr, info_ptr, *columns, *rows, 8,
		   PNG_COLOR_TYPE_RGB, PNG_INTERLACE_ADAM7,
		   PNG_COMPRESSION_TYPE_DEFAULT,
		   PNG_FILTER_TYPE_DEFAULT);
      if (getenv("SCREEN_GAMMA") != NULL)   /*  warning athlon cc  */
	{
	  gamma_str = getenv("SCREEN_GAMMA");
	  screen_gamma = atof(gamma_str);
	}
      else
	{
#if defined(Linux)
	  screen_gamma = 2.5;	/* Guess for a PC.*/
#elif defined(SunOS)
	  screen_gamma = 2.5;	/* Guess for a Sun.*/
#elif defined(IRIX) || defined(IRIX64)
	  screen_gamma = 1.7;	/* Guess for an SGI.*/
#else
	  screen_gamma = 2.5;
#endif
	}
      png_set_gAMA(png_ptr, info_ptr, 1.0 / screen_gamma);
      png_write_info(png_ptr, info_ptr);
      
/* Allocate the memory to hold the image using the fields of info_ptr.  */
      row_pointers = (png_bytep*)malloc(sizeof(png_bytep) * *rows);
      if (!row_pointers)
	{
	  printf("void fImageT<T>::readPNG(const string&)");
	}
      for (r = 0; r < *rows; r++)
	{
	  row_pointers[r] = (png_bytep)malloc(png_get_rowbytes(png_ptr, info_ptr));
	  if (!row_pointers[r])
	    {
	      printf("void fImageT<T>::readPNG(const string&)");
	    }
	}
      pix=-1;
      for (r = 0; r < *rows; r++)
	{
	  for (c = 0; c < *columns; c++)
	    {
	      pix+=1;
	      pixel=img[pix];
	      row_pointers[r][3*c+0] =  pixel & 0x000000ff;
	      row_pointers[r][3*c+1] = (pixel & 0x0000ff00)>>8;
	      row_pointers[r][3*c+2] = (pixel & 0x00ff0000)>>16;
	    }
	}
      /* Write the image.*/
      png_write_image(png_ptr, row_pointers);
      png_write_end(png_ptr, info_ptr);
      /*       Close the file.   */
      fclose(fp);
      
      /* Free the allocated memory.*/
      png_destroy_write_struct(&png_ptr, &info_ptr);
      for (r = 0; r < *rows; r++)
	{
	  free(row_pointers[r]);
	}
      free(row_pointers);
      return(0);
    }   
/*    return(success); */
}


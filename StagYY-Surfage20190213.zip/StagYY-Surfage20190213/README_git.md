StagYY is now tracked via git. 

Git is a "Version Control System," which is a piece of software to help track
the history of a software project and allow multiple developers to improve it.
With the help of web services like GitHub, it also provides a very convenenient
way to distribute code and organize the addition of new features from users.

# The Master Branch of StagYY
The canonical version of StagYY is referred to as "master".

You can take a look at this version of the code on GitHub, at
https://github.com/ptackley/StagYY

## Checking out the code with git and obtaining updates
If you plan to add to the code, or simply want to be able to very quickly 
obtain bug fixes, it's convenient to use git.

If you prefer not to use command-line tools, you can use a GUI tool 
with git. Here, we describe the usage of GitHub Desktop, 
https://desktop.github.com/, but others like SourceTree operate similarly.

1. Make sure that you have access to the StagYY GitHub repository (see README.md)
2. Download and Install GitHub Desktop from the link above
3. Open the GitHub Desktop application and follow the setup instructions (you might as well install the command line tools).
4. Select File->Clone Repository.. and select ptackley/StagYY, choosing a location to place the code
5. To obtain any new changes, click the "Sync" button. 

## Working with a modified version of the code
You may want to add new features to the code. You can do this on your own "branch"!

1. Clone the master branch of the repository as above
2. Create your own branch by clicking the "create new branch" button near the top left. Name the branch
   something like "yourname/description-of-feature" and branch from master (the default).
3. Make changes, add files, and create commits using the GUI interface.
4. To be able to see your branch on GitHub (and allow others to see it), use Branch-->Publish. You will now see your branch at
https://github.com/ptackley/StagYY/branches
5. To push your latest changes up, click "Sync"

-------------------------------------------------------------------------------

# Using Command-line tools
You also have the option, if you are interested, of using git's command-line tools.

## Checking out the code and obtaining updates
1. Install the git program on your machine. See
https://git-scm.com/book/en/v2/Getting-Started-Installing-Git

2. Inform git of your identity. From the command line,

   ````
   git config --global user.name "My Name"
   git config --global user.email my.name@erdw.ethz.ch
   ````

   Make sure that the email address is the same one that you use for your GitHub account.
   You can add the command above to your login file (`.bashrc`).

3. Clone the StagYY repository

   ````
   git clone https://github.com/ptackley/StagYY.git
   ````

You should now have the master version of StagYY in a directory named "StagYY"

4. To obtain any updates to the master branch of StagYY,
a. Make sure that you have informed git of your identity as in 2.
b. cd to the stagyy directory

   ````
   cd StagYY
   ````

c. "Pull" (fetch and merge) any changes

   ````
   git pull
   ````
   
## Working with a modified version of the code
1. Clone the master branch of the repository as above, and cd to the stagyy directory.
2. Make sure that the master branch is up to date

   ````
   git pull
   ````

3. Create your own branch and check it out

   ````
   git branch myname/my-feature
   git checkout myname/my-feature
   ````

4. As you work, make commits 

   ````
   git add file1 
   git commit -m"file1: made change X"
   ````

5. Set up your branch to "track" a branch on GitHub, so that you can easily see your differences.

   ````
   git push -u origin myname/my-feature
   ````

6. Periodically, push to GitHub to back up and let others see how your code differs from master
   ````
   git push 
   ````
## Checking out your branch on a remote machine
This proceeds almost exactly as cloning StagYY, as described above. 
Simply add a final step which checks out your branch!

   ````
   git checkout myname/my-feature
   ````

# Additional Resources
1. This document is in development, so please contact patrick.sanan@erdw.ethz.ch with requests or questions
2. See these tutorial slides by @psanan: https://bitbucket.org/psanan/gittutorial
3. Various online tutorials, for example on GitHub: https://help.github.com/articles/good-resources-for-learning-git-and-github/
4. The git book (very long, but comprehensive) : https://git-scm.com/book/en/v2

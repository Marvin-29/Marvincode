#include <stdio.h>

int png_present_()
{  
  return 0;
}

void write_png_( char *fileName, unsigned long long  *img, int *columns, int *rows)
{
  printf("StagYY was not compiled with PNG support. No PNG output was written!\n");
}


#include <stdio.h>
#include <sys/file.h>
#include <fcntl.h>
#include <sys/types.h>
#include <unistd.h>

int copen_ (name,mode)
char *name ;
int *mode ;
{  
  int fd ;
  if (*mode==1) {
    fd = open(name,O_RDONLY);}
  else {
     fd = open(name,O_RDWR | O_CREAT,0644);}
  return fd;
}
int copen (name,mode)
char *name ;
int *mode ;
{  
  int fd ;
  if (*mode==1) {
    fd = open(name,O_RDONLY);}
  else {
     fd = open(name,O_RDWR | O_CREAT,0644);}
  return fd;
}

int copenc_ (mode,name)
char *name ;
int *mode ;
{  
  int fd ;
  if (*mode==1) {
    fd = open(name,O_RDONLY);}
  else {
     fd = open(name,O_RDWR | O_CREAT,0644);}
  return fd;
}
int copenc (mode,name)
char *name ;
int *mode ;
{  
  int fd ;
  if (*mode==1) {
    fd = open(name,O_RDONLY);}
  else {
     fd = open(name,O_RDWR | O_CREAT,0644);}
  return fd;
}

int cread_ (fd,buf,len)
int *fd ;
char *buf ;
int *len ;
{
  return read (*fd,buf,*len) ;
}

int cread (fd,buf,len)
int *fd ;
char *buf ;
int *len ;
{
  return read (*fd,buf,*len) ;
}

int cwrite_ (fd,buf,len)
int *fd ;
char *buf ;
int *len ;
{
  return write (*fd,buf,*len) ;
}

int cwrite (fd,buf,len)
int *fd ;
char *buf ;
int *len ;
{
  return write (*fd,buf,*len) ;
}

int cclose_ (fd)
int *fd ;
{
  close(*fd);
  return 0;
}

int cclose (fd)
int *fd ;
{
  close(*fd);
  return 0;
}

long lseek_ (fd,offset,whence)
int *fd, *whence;
long *offset;
{
  off_t ll;
  printf ("%d,%ld,%d,",*fd,*offset,*whence);
 /* ll = lseek (*fd,*offset,*whence) ;*/
  ll = lseek (*fd,0L,2);
  printf ("%lld",(long long int)ll);
  return ll;
}

int COPEN (name,mode)
char *name ;
int *mode ;
{  
  int fd ;
  if (*mode==1) {
    fd = open(name,O_RDONLY);}
  else {
     fd = open(name,O_RDWR | O_CREAT,0644);}
  return fd;
}

int COPENC (mode,name)
char *name ;
int *mode ;
{  
  int fd ;
  if (*mode==1) {
    fd = open(name,O_RDONLY);}
  else {
     fd = open(name,O_RDWR | O_CREAT,0644);}
  return fd;
}

int CREAD (fd,buf,len)
int *fd ;
char *buf ;
int *len ;
{
  return read (*fd,buf,*len) ;
}

int CWRITE (fd,buf,len)
int *fd ;
char *buf ;
int *len ;
{
  return write (*fd,buf,*len) ;
}

int CCLOSE (fd)
int *fd ;
{
  close(*fd);
  return 0;
}



/* possible C replacement for UNIX FORTRAN routine ETIME */
/*  from the internet */
/* added on 11 Oct 2005 for IBM XLF compiler */
/*
#include <stdio.h>
#include <sys/time.h>
#include <sys/times.h>

float etime(et)
float et[2];
{
  clock_t clicks;
  clicks = clock();
  return ( (float) clicks / CLOCKS_PER_SEC );
}
*/

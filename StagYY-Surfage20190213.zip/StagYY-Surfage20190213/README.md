# StagYY

If you are trying to quickly run on Leonhard, Euler, or OS X, consider the quickstart sections below. Otherwise, skip down to "Building StagYY"

## Leonhard Quickstart (2018.07.26)

1. Go to 'Releases' on the [StagYY GitHub page](https://github.com/ptackley/StagYY) and download the latest release as a `.tar.gz` file

2. Copy the downloaded file (named something like `StagYY-1.0.8.tar.gz`) to Leonhard.

3. On Leonhard, expand the file, for example

        tar xzvf StagYY-1.0.8.tar.gz

4. `cd` to the directory that was just created, for example

        cd StagYY-1.0.8

5. Make sure that you have the correct modules loaded (see `makefile_examples/makefile.leonhard.petsc`), for example

        module purge && module load gcc/6.3.0 openmpi/2.1.0 hdf5/1.10.1 openblas/0.2.19 petsc/3.6.4 libpng/1.6.27 python_cpu/3.6.4

6. Copy an example makefile

        cp makefile_examples/makefile.leonhard.petsc Makefile

7. Build StagYY

        make -j

8. Use the resulting `stagyympi` executable. If you log out and back in,
reload the modules in step 5 before running your job.

## Euler Quickstart (2018.03.20)

1. Go to 'Releases' on the [StagYY GitHub page](https://github.com/ptackley/StagYY) and download the latest release as a `.tar.gz` file

2. Copy the downloaded file (named something like `StagYY-1.0.8.tar.gz`) to Euler.

3. On Euler, expand the file, for example

        tar xzvf StagYY-1.0.8.tar.gz

4. `cd` to the directory that was just created, for example

        cd StagYY-1.0.8

5. Make sure that you have the correct modules loaded

        module purge; module load gcc open_mpi hdf5 openblas new petsc

6. Copy the example makefile

        cp makefile_examples/makefile.euler.petsc Makefile

7. Build StagYY

        make -j

8. Use the resulting `stagyympi` executable. If you log out and back in,
reload the modules in step 5 before running your job.

## OS X Quickstart (2017.11.08 OS X 10.12)

0. Open the Terminal application.

1. Make sure that you do not have any old `PETSC_DIR` or `PETSC_ARCH` variables set in your environment by your `.bashrc`, other login file, or previous installation attempt. If you do, remove any such settings from your login file and start in a new terminal.

        echo $PETSC_DIR        # should be empty
        echo $PETSC_ARCH       # should be empty

2. Install C and Fortran compilers. If you use MacPorts or Homebrew, you can use those tools. However, the easiest path is to follow the instructions at http://hpc.sourceforge.net to install `gcc` and `gfortran`, and check:

        which gcc          # should give /usr/local/bin/gcc
        which gfortran     # should give /usr/local/bin/gfortran
        
You can confirm that your compilers are working in a very simple case with these commands (each of which should print "OK!")

        printf '#include<stdio.h>\nint main(){printf("OK!\\n");}' > t.c && gcc t.c && ./a.out && rm t.c a.out
        printf 'program t\nprint"(a)","OK!"\nend program' > t.f90 && gfortran t.f90 && ./a.out && rm t.f90 a.out

3. [Download PETSc 3.7.7](https://www.mcs.anl.gov/petsc/download/index.html) (you must use version 3.7, not a later version) and expand the tarball to your home directory.

        cd  ~
        tar xzvf ~/Downloads/petsc-3.7.7.tar.gz

4. Configure and build PETSc. Note the value of `PETSC_ARCH`, which will be something like `arch-darwin-c-opt`.

        cd petsc-3.7.7
        ./configure --with-fc=gfortran --with-cc=gcc --with-cxx=g++ --download-mpich --download-hdf5 --download-metis --download-parmetis --download-scalapack --download-mumps --download-suitesparse --with-debugging=no --FOPTFLAGS='-g -O3' --COPTFLAGS='-g -O3' --CXXOPTFLAGS='-g -O3' --download-fblaslapack --download-cmake
        # follow instructions to make and test

5. Set environment variables `PETSC_ARCH` and `PETSC_DIR`. You may want to add these to your `.bashrc` or other login file.

        export PETSC_DIR=$PWD                       # this directory (use literal path in .bashrc)
        export PETSC_ARCH=arch-darwin-c-opt         # replace with value noted above

6. Go to 'Releases' on the StagYY GitHub page and download the latest release as a .tar.gz file. This will be named something like `StagYY-1.0.3.tar.gz`.

7. Expand the downloaded file, for example

        cd ~
        tar xzvf ~/Downlods/StagYY-1.0.3.tar.gz

8. Build StagYY

        cd StagYY-1.0.3
        cp makefile_examples/makefile.osx.petsc Makefile
        make -j

9. Use the stagyympi executable. Note that you should use the MPI that PETSc
  built for you, e.g.

        export PETSCMPIEXEC=$PETSC_DIR/$PETSC_ARCH/bin/mpiexec # can go in your login file
        mkdir -p +op +im && rm -f +im/* +op/*
        $PETSCMPIEXEC -np 2 ./stagyympi

10. Check output. The temperature field after the first output step (`+im/Blankenbach_T00001.png`) should appear as
![Blankenbach_T00001.png](doc/quickstart/Blankenbach_T00001.png)

## Obtaining StagYY
### Release Version
Go to [the StagYY GitHub page](https://github.com/ptackley/StagYY)
and click on "releases" to see numbered versions, which you can download as
`.zip` or `.tar.gz` .

If you get a "404" error, then likely you need to
to make sure that you are logged into GitHub and
have been given access to the repository.

### Latest Version
Go to [the StagYY GitHub page](https://github.com/ptackley/StagYY)
and click on "Clone or download".

# Building StagYY

### Prerequisites

You will need working Fortran 90 and C compilers, such as recent versions of
gfortran and gcc. MPI and HDF5 libraries are also recommended.

If you plan on using PETSc with StagYY, see `PETSC_INSTRUCTIONS.txt`
and install PETSc.

### Building

To build StagYY, you must provide a `Makefile`. Fortunately,
most of the work has been done for you already!

You should begin by copying an appropriate example makefile, e.g.

    cp makefile_examples/makefile.osx.petsc Makefile

You can then edit the makefile further, if desired.
Note: you do not have to fill in all of the empty variables.

When your makefile is set up appropriately, type

    make -j

to build in parallel.

## User Guide
See `doc/README.md`

## Tests (in progress)
See `tests/README.md`

## Using a Modified Version of StagYY
See `README_git.md`
